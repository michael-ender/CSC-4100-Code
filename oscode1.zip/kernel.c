#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void k_print(char *string, int string_length, int row, int col);

void k_clearscr() {
    char clear[1] = " ";

    for (int i = 0; i < 25; i++) {
        for (int j = 0; j < 80; j++) {
            k_print(clear, 1, i, j);        
        }
    }
}

void print_border(int start_row, int start_col, int end_row, int end_col){          //all values predifined and circle rows and columns passed to k_print
    char dash[2] = "-";
    char plus[2] = "+";
    char line[2] = "|";
    k_print(plus, 1, start_row, start_col);             //top left plus
    for(int i = start_col + 1; i < end_col; i++){       //first dashes
        k_print(dash, 1, start_row, i);                 
    }
    k_print(plus, 1, start_row, end_col);               //top rigth plus
    for(int i = start_row + 1; i < end_row; i++) {      //lines going down left side
        k_print(line, 1, i, start_col);
    }
    for(int i = start_row + 1; i < end_row; i++) {      //lines going down right side
        k_print(line, 1, i, end_col);
    }
    k_print(plus, 1, end_row, start_col);               //bottom left plus
    for(int i = start_col + 1; i < end_col; i++){       //bottom lines
        k_print(dash, 1, end_row, i);
    }
    k_print(plus, 1, end_row, end_col);                 //bottom right plus
}

int main () {

    char word[7] = "OS 4100";
    int length = 7;
    int rows = 12;
    int columns = 37;
    int start_row = 4;
    int end_row = 20;
    int start_col = 22;
    int end_col = 56;

    k_clearscr();
    print_border(start_row, start_col, end_row, end_col);
    k_print(word, length, rows, columns);

    while(1){ }
    return 0;
}